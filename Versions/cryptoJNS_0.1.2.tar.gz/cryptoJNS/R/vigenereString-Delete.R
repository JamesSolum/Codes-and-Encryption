#' Vigenere
#'
#' @param txt a string you would like to encrypt
#' @param keyVector a vector to encrypt your string with
#'
#' @return an encrypted string
#' @export
#'
#' @examples vigenere("helloworld", "at")
vigenereString <- function(txt, keyVector)
{
  kv <- stringToMod26(keyVector)
  pt <- stringToMod26(txt)
  suppressWarnings(
    ct <- (pt + kv) %% 26
  )
  return(mod26ToString(ct))
}
