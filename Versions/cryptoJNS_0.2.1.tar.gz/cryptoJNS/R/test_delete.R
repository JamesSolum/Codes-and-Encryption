#' Title
#'
#' @param m
#' @param ky
#' @param iv
#'
#' @return
#' @export
#'
#' @examples
test <- function(m, ky, iv){

  if((length(m) %% 16) != 0)
    stop("Message length is not a multiple of 128-bits.")


  numOfBlks <- length(m)/16
  x <- md5(charToRaw(iv))
  o <- raw(length = 16)
  ct <- raw(length = length(m))
  o[1:16] <- md5(x, ky)

  for (i in 1:numOfBlks){
    x <- o[((16*(i-1))+1):(16*i)]
    o[(((16*(i-1))+1)+16):((16*i)+16)] <- md5(x, ky)
  }

  for (i in 1:numOfBlks){
    ct[((16*(i-1))+1):(16*i)] <- xor((m[((16*(i-1))+1):(16*i)]), (o[((16*(i-1))+1):(16*i)]))
  }

  return(ct)
}
