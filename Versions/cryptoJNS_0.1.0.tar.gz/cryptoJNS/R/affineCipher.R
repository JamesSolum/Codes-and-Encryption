#' Encrypt a string using a shift cipher
#'
#' @param plainText A string of lowercase letters
#' @param stretch An integer (mod 26) to stretch by
#' @param shift An integer (mod 26) to shift by
#'
#' @return An encrypted (or decrypted) string, where each letter has been shifted by \code{shift} places.
#' @export
#'
#' @examples
#' plainText <- "dog"
#' cipherText <- shiftCipher(plainText,3,7)
#' print(cipherText)
affineCipher <- function(plainText,stretch,shift){
  pt <- stringToMod26(plainText)
  ct <- ((pt*stretch) + shift) %% 26  # encrypt by stretching and shifting
  return(mod26ToString(ct))
}
