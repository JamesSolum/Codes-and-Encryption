#' Hamming distance
#'
#' Compute the Hamming distance between two n-dimensional vectors in Z_2.
#'
#' @param c1 A vector of 0's and 1's of length 2.
#' @param c2 A vector of 0's and 1's of length 2.
#'
#' @return The number of positions where \code{c1} and \code{c2} differ.
#' @export
#'
#' @examples
#' hammingDistance(c(1,0,0,1,1), c(0,1,0,1,0))
hammingDistance <- function(c1, c2) {
  count <- 0

  for(i in 1:length(c1)){
    if(c1[i] != c2[i]){
      count <- count + 1
    }
  }
  return(count)
}

#' Minimum distance of a code
#'
#' Compute the smallest Hamming distance between two words of a code.
#'
#' @param C A code, represented as a matrix of 0's and 1's. The rows
#' of this matrix are the words of the code.
#'
#' @return The minimum distance d(C) of the code.
#' @export
#'
#' @examples
#' codeDistance(matrix(c(0,1,0,0,1, 0,0,1,1,1, 0,1,0,0,0, 1,1,1,1,1), nrow=4, byrow=TRUE))
codeDistance <- function(C) {
  minDist <- hammingDistance(C[1, ], C[2, ])

  for(i in 1:nrow(C)){
    for(j in 1:nrow(C)){
      if(i != j){
        a <- hammingDistance(C[i, ], C[j, ])
        if(minDist > a){
          minDist <- a
        }
      }
    }
  }

  return(minDist)
}

#' Generate a code from a basis
#'
#' @param B A list of basis code words, represented as a matrix of 0's
#' and 1's. The rows of this matrix are the basis code words. Assume that
#' the maximum size of a basis is 32. (The function does not require that
#' the rows of B be linearly independent.)
#'
#' @return A matrix consisting of all possible, distinct, linear combinations
#' of the basis code words over Z_2.
#' @export
#'
#' @examples
#' generateCode(matrix(c(1,0,0,0,1,1,0,
#'                       0,1,0,0,1,0,1,
#'                       0,0,1,0,0,1,1,
#'                       0,0,0,1,1,1,1), nrow=4, byrow=TRUE))
generateCode <- function(B) {
  posCom <- 2^(nrow(B))
  linComb <- c()
  for(i in 1:posCom){
    combinations <- (as.numeric(intToBits(i)))[1:nrow(B)]
    linComb <- c(linComb, ((as.vector(combinations %*% B)) %% 2))
  }
  return(unique(matrix(linComb, nrow=posCom, byrow=TRUE)))
}

#' Determine whether a code is perfect
#'
#' Given a code C, determines whether the number of codewords equals the Hamming
#' sphere packing bound.
#'
#' @param C A code, represented as a matrix of 0's and 1's. The rows
#' of this matrix are the words of the code.
#'
#' @return TRUE if the code is perfect, FALSE if not.
#' @export
#'
#' @examples
#' isPerfect(generateCode(matrix(c(1,0,0,0,1,1,0,
#'                                 0,1,0,0,1,0,1,
#'                                 0,0,1,0,0,1,1,
#'                                 0,0,0,1,1,1,1), nrow=4, byrow=TRUE)))
isPerfect <- function(C) {
  n <- ncol(C)
  M <- nrow(C)
  d <- codeDistance(C)
  t <- (d - 1)/2
  bottom <- 0
  top <- 2^n

  for (i in 1:t){
    bottom <- ((factorial(n))/((factorial(i)) * (factorial(n-i)))) + bottom
  }

  HsphereBound <- top/bottom

  if(M == HsphereBound){
    return(TRUE)
  } else{
    return(FALSE)
  }
}
