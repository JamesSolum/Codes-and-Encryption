#' Factor Number will factor a number
#'
#' @param p a number you would like to factor
#'
#' @return a list of all the factors in pfa
#' @export
#'
#' @examples
#' factornumber(6)
factornumber <- function(p){
  number <- p
  factornumber <- 1
  factorlist <- c()
  i <- 1
  while (factornumber < number) {
    if(number %% factornumber == 0){
      factorlist <- c(factorlist,factornumber)
      factornumber <- factornumber + 1
    } else {
      factornumber <- factornumber + 1
    }
  }
  return(factorlist)
}

